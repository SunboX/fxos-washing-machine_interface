wm.Config = {
    ApiServerPort: 8080,
    waterApiUrl: 'http://water-opendatade.rhcloud.com/water.json',
    washingPowderApiUrl: 'http://detergent-opendatade.rhcloud.com/washingPowder.json',
    fabricConditionerApiUrl: 'http://detergent-opendatade.rhcloud.com/fabricConditioner.json'
};