/**
 * Wraps navigator.bluetooth for replacing it in unit tests more easily.
 */
define([],function() {
  

  if (navigator.mozBluetooth) {
	return navigator.mozBluetooth;
  } else {
	return null;
  }
});
