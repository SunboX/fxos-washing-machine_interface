'use strict';
/* exported MockAlphaScroll */

var MockAlphaScroll = {
  init: function(params) {
    return;
  },
  toggleFormat: function() {
    return;
  }
};
