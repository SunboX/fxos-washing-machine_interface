document.getElementById('close').onclick = function() {
  window.close();
};

document.getElementById('open').onclick = function() {
  window.open('/tests_html/UI/popup.html', '', 'dialog');
};